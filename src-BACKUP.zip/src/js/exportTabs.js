console.log('ExportTabs.js loading...');

document.addEventListener("DOMContentLoaded", function() {
  console.log('DOM loaded, setting up export tabs...');
  
  const exportBtn = document.getElementById("exportAllTabs");
  console.log('Export button found:', exportBtn);
  
  if (exportBtn) {
    exportBtn.addEventListener("click", function() {
      console.log('Export button clicked');
      
      chrome.runtime.sendMessage({action: "exportTabs"}, function(response) {
        console.log('Export response:', response);
        
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          alert("Error: " + chrome.runtime.lastError.message);
          return;
        }
        
        if (response && response.tabs && Array.isArray(response.tabs)) {
          console.log('Creating download for', response.tabs.length, 'tabs');
          
          const data = JSON.stringify({tabs: response.tabs}, null, 2);
          const blob = new Blob([data], {type: "application/json"});
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "tabs_export.json";
          document.body.appendChild(a);
          a.click();
          
          setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 100);
          
          alert(`✅ Exported ${response.tabs.length} tabs successfully!`);
        } else {
          console.error('Invalid response:', response);
          alert("❌ Failed to export tabs - Invalid response");
        }
      });
    });
  } else {
    console.error('Export button with ID "exportAllTabs" not found');
  }
});
