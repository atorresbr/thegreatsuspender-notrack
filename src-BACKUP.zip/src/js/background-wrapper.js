/**
 * FIXED Background Service Worker - Proper Manifest V3 Implementation
 */

console.log('🚀 Service Worker starting...');

// Global state
let isServiceWorkerReady = false;
let suspendedTabs = new Map();
let sessionData = { id: null, created: Date.now(), tabs: [] };
let contextMenusCreated = false; // Prevent duplicate context menus

// Simple initialization without problematic SW APIs
async function initializeServiceWorker() {
    try {
        console.log('🔧 Initializing Service Worker...');
        
        // Set default storage values
        const defaults = {
            extensionEnabled: true,
            selectedTheme: 'purple',
            tabProtection: true,
            autoRestore: true,
            systemThemeBehavior: 'manual',
            suspendAfter: 60
        };
        
        // Initialize defaults
        for (const [key, value] of Object.entries(defaults)) {
            try {
                const result = await chrome.storage.local.get([key]);
                if (result[key] === undefined) {
                    await chrome.storage.local.set({ [key]: value });
                }
            } catch (error) {
                console.warn(`Failed to set default ${key}:`, error);
            }
        }
        
        // Create session ID if needed
        const sessionResult = await chrome.storage.local.get(['currentSessionId']);
        if (!sessionResult.currentSessionId) {
            const newId = `gs-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
            await chrome.storage.local.set({ currentSessionId: newId });
            sessionData.id = newId;
        } else {
            sessionData.id = sessionResult.currentSessionId;
        }
        
        // Setup context menu only once
        if (!contextMenusCreated) {
            await setupContextMenu();
        }
        
        isServiceWorkerReady = true;
        console.log('✅ Service Worker initialized successfully');
        
    } catch (error) {
        console.error('❌ Service Worker initialization error:', error);
        isServiceWorkerReady = true;
    }
}

// SINGLE UNIFIED MESSAGE HANDLER
function handleMessage(request, sender, sendResponse) {
    try {
        console.log('📨 Background received:', request.action);
        
        switch(request.action) {
            // Session Management Actions
            case 'exportTabs':
                console.log('Processing exportTabs...');
                chrome.tabs.query({}, (tabs) => {
                    const exportTabs = tabs.filter((tab) =>
                        tab.url &&
                        !tab.url.startsWith("chrome://") &&
                        !tab.url.startsWith("chrome-extension://")
                    ).map((tab) => ({
                        title: tab.title,
                        url: tab.url
                    }));
                    console.log('Exporting tabs:', exportTabs.length);
                    sendResponse({tabs: exportTabs});
                });
                return true;
                
            case 'importTabs':
                try {
                    const imported = JSON.parse(request.jsonData);
                    const tabsArray = imported.tabs || imported;
                    if (!Array.isArray(tabsArray)) {
                        sendResponse({success: false, error: "Invalid format"});
                        return true;
                    }
                    tabsArray.forEach((tab) => {
                        if (tab.url) chrome.tabs.create({url: tab.url});
                    });
                    sendResponse({success: true, imported: tabsArray.length});
                } catch (err) {
                    console.error('Import error:', err);
                    sendResponse({success: false, error: err.message});
                }
                return true;
                
            case 'backupTabs':
                chrome.tabs.query({}, (tabs) => {
                    chrome.storage.local.set({backupTabs: tabs}, () => {
                        sendResponse({success: true, count: tabs.length});
                    });
                });
                return true;
                
            case 'restoreSession':
                const sessionId = request.sessionId;
                chrome.storage.local.get([sessionId], (result) => {
                    const sessionTabs = result[sessionId] || [];
                    sessionTabs.forEach((tab) => {
                        if (tab.url) chrome.tabs.create({url: tab.url});
                    });
                    sendResponse({success: true, restored: sessionTabs.length});
                });
                return true;
                
            case 'createSession':
                chrome.tabs.query({}, (tabs) => {
                    const sessionId = "session_" + Date.now();
                    chrome.storage.local.set({[sessionId]: tabs}, () => {
                        sendResponse({success: true, sessionId: sessionId, count: tabs.length});
                    });
                });
                return true;
                
            case 'getSessionId':
                chrome.storage.local.get(null, (data) => {
                    const sessionIds = Object.keys(data).filter((k) => k.startsWith("session_"));
                    const latestId = sessionIds.sort().pop() || "none";
                    sendResponse({sessionId: latestId});
                });
                return true;
                
            // Original Tab Suspension Actions
            case 'getCurrentSessionId':
                chrome.storage.local.get(['currentSessionId'], (result) => {
                    sendResponse({ success: true, sessionId: result.currentSessionId });
                });
                return true;
                
            case 'createNewSession':
                const newId = `gs-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
                chrome.storage.local.set({ currentSessionId: newId }, () => {
                    sendResponse({ success: true, sessionId: newId });
                });
                return true;
                
            case 'suspendTab':
                suspendTab(request.tabId || sender.tab?.id).then((result) => {
                    sendResponse(result);
                });
                return true;
                
            case 'unsuspendTab':
                unsuspendTab(request.tabId || sender.tab?.id).then((result) => {
                    sendResponse(result);
                });
                return true;
                
            case 'suspendOtherTabs':
                suspendOtherTabs(request.activeTabId || sender.tab?.id).then((result) => {
                    sendResponse(result);
                });
                return true;
                
            case 'unsuspendAllTabs':
                unsuspendAllTabs().then((result) => {
                    sendResponse(result);
                });
                return true;
                
            case 'getSuspendedCount':
                getSuspendedTabsCount().then((result) => {
                    sendResponse(result);
                });
                return true;
                
            case 'openOptions':
                chrome.runtime.openOptionsPage();
                sendResponse({ success: true });
                return true;
                
            case 'getTabInfo':
                getTabInfo(request.tabId).then((result) => {
                    sendResponse(result);
                });
                return true;
                
            default:
                sendResponse({ success: false, error: 'Unknown action: ' + request.action });
                return true;
        }
    } catch (error) {
        console.error('❌ Message handler error:', error);
        sendResponse({ success: false, error: error.message });
        return true;
    }
}

// Tab suspension functions
async function suspendTab(tabId) {
    try {
        if (!tabId) return { success: false, error: 'No tab ID provided' };
        
        const tab = await chrome.tabs.get(tabId);
        if (!canSuspendTab(tab)) {
            return { success: false, error: 'Tab cannot be suspended' };
        }
        
        const suspendedUrl = chrome.runtime.getURL('suspended.html') + 
            '?uri=' + encodeURIComponent(tab.url) + 
            '&title=' + encodeURIComponent(tab.title);
        
        await chrome.tabs.update(tabId, { url: suspendedUrl });
        
        suspendedTabs.set(tabId, {
            id: tabId,
            url: tab.url,
            title: tab.title,
            suspended: Date.now()
        });
        
        return { success: true };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function unsuspendTab(tabId) {
    try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.url.includes('suspended.html')) {
            const urlParams = new URLSearchParams(tab.url.split('?')[1] || '');
            const originalUrl = urlParams.get('uri') || urlParams.get('url');
            
            if (originalUrl) {
                await chrome.tabs.update(tabId, { url: decodeURIComponent(originalUrl) });
                suspendedTabs.delete(tabId);
                return { success: true };
            }
        }
        return { success: false, error: 'Tab is not suspended' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function suspendOtherTabs(activeTabId) {
    try {
        const tabs = await chrome.tabs.query({ currentWindow: true });
        let suspended = 0;
        
        for (const tab of tabs) {
            if (tab.id !== activeTabId && canSuspendTab(tab)) {
                const result = await suspendTab(tab.id);
                if (result.success) suspended++;
            }
        }
        
        return { success: true, suspended };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function unsuspendAllTabs() {
    try {
        const tabs = await chrome.tabs.query({});
        let unsuspended = 0;
        
        for (const tab of tabs) {
            if (tab.url.includes('suspended.html')) {
                const result = await unsuspendTab(tab.id);
                if (result.success) unsuspended++;
            }
        }
        
        return { success: true, unsuspended };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

function canSuspendTab(tab) {
    return tab && 
           !tab.url.includes('chrome://') && 
           !tab.url.includes('chrome-extension://') && 
           !tab.url.includes('suspended.html') &&
           !tab.url.includes('about:') &&
           tab.url !== '';
}

async function getSuspendedTabsCount() {
    try {
        const tabs = await chrome.tabs.query({});
        const suspendedCount = tabs.filter((tab) => tab.url.includes('suspended.html')).length;
        return {
            success: true,
            count: suspendedCount,
            estimatedMemory: suspendedCount * 75
        };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function getTabInfo(tabId) {
    try {
        let tab;
        if (tabId) {
            tab = await chrome.tabs.get(tabId);
        } else {
            [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        }
        
        return {
            success: true,
            tab: {
                id: tab.id,
                title: tab.title,
                url: tab.url,
                suspended: tab.url.includes('suspended.html')
            }
        };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// Fixed context menu setup with proper error handling and duplicate prevention
async function setupContextMenu() {
    return new Promise((resolve) => {
        // First, remove all existing context menus
        chrome.contextMenus.removeAll(() => {
            if (chrome.runtime.lastError) {
                console.warn('Context menu removeAll error:', chrome.runtime.lastError.message);
            }
            
            const menuItems = [
                { id: 'suspend-tab', title: '💤 Suspend this tab', contexts: ['page'] },
                { id: 'suspend-other', title: '😴 Suspend other tabs', contexts: ['page'] },
                { id: 'unsuspend-all', title: '🔄 Unsuspend all tabs', contexts: ['page'] }
            ];
            
            let itemsCreated = 0;
            const totalItems = menuItems.length;
            
            menuItems.forEach((item) => {
                chrome.contextMenus.create(item, () => {
                    if (chrome.runtime.lastError) {
                        console.warn(`Context menu creation error for ${item.id}:`, chrome.runtime.lastError.message);
                    } else {
                        console.log(`✅ Context menu created: ${item.id}`);
                    }
                    
                    itemsCreated++;
                    if (itemsCreated === totalItems) {
                        contextMenusCreated = true;
                        resolve();
                    }
                });
            });
        });
    });
}

// Context menu click handler
function handleContextMenuClick(info, tab) {
    try {
        switch(info.menuItemId) {
            case 'suspend-tab':
                suspendTab(tab.id).then((result) => {
                    console.log('Suspend tab result:', result);
                });
                break;
            case 'suspend-other':
                suspendOtherTabs(tab.id).then((result) => {
                    console.log('Suspend other tabs result:', result);
                });
                break;
            case 'unsuspend-all':
                unsuspendAllTabs().then((result) => {
                    console.log('Unsuspend all tabs result:', result);
                });
                break;
        }
    } catch (error) {
        console.error('Context menu action error:', error);
    }
}

// Event listeners - use named functions to avoid anonymous function errors
function handleInstalled(details) {
    console.log('🔧 Extension installed:', details.reason);
    initializeServiceWorker();
}

function handleStartup() {
    console.log('🚀 Extension startup');
    initializeServiceWorker();
}

// Setup event listeners
chrome.runtime.onInstalled.addListener(handleInstalled);
chrome.runtime.onStartup.addListener(handleStartup);

// SINGLE MESSAGE LISTENER - use named function
chrome.runtime.onMessage.addListener(handleMessage);

// Context menu click listener - use named function
chrome.contextMenus.onClicked.addListener(handleContextMenuClick);

// Initialize immediately
initializeServiceWorker();
