// Options.js - Control panel functionality
console.log('Options.js loading...');

document.addEventListener('DOMContentLoaded', function() {
    console.log('Options page DOM loaded');
    
    // Initialize options from storage
    initializeOptions();
    
    // Set up event listeners for all options controls
    setupEventListeners();
});

function initializeOptions() {
    console.log('Initializing options from storage...');
    
    // Load saved options
    chrome.storage.sync.get([
        'theme',
        'autoSuspendTime',
        'pinned',
        'whiteList',
        'neverSuspendForms',
        'suspendInPlaceOfDiscard',
        'discardAfterSuspend'
    ], function(items) {
        console.log('Loaded options:', items);
        
        // Set default theme to "system" (Follow System Theme)
        const theme = items.theme || 'system';
        const themeSelect = document.getElementById('theme');
        if (themeSelect) {
            themeSelect.value = theme;
            applyTheme(theme);
        }
        
        // Set auto suspend time
        const autoSuspendTime = document.getElementById('timeToSuspend');
        if (autoSuspendTime) {
            autoSuspendTime.value = items.autoSuspendTime || '60';
        }
        
        // Set "don't suspend pinned tabs" checkbox
        const pinnedCheckbox = document.getElementById('dontSuspendPinned');
        if (pinnedCheckbox) {
            pinnedCheckbox.checked = items.pinned !== false; // Default to true
        }
        
        // Set whitelist
        const whiteListTextarea = document.getElementById('whitelist');
        if (whiteListTextarea) {
            whiteListTextarea.value = items.whiteList || '';
        }
        
        // Set "never suspend forms" checkbox
        const neverSuspendFormsCheckbox = document.getElementById('neverSuspendForms');
        if (neverSuspendFormsCheckbox) {
            neverSuspendFormsCheckbox.checked = items.neverSuspendForms !== false; // Default to true
        }
        
        // Set "suspend in place of discard" checkbox
        const suspendInPlaceCheckbox = document.getElementById('suspendInPlaceOfDiscard');
        if (suspendInPlaceCheckbox) {
            suspendInPlaceCheckbox.checked = items.suspendInPlaceOfDiscard !== false; // Default to true
        }
        
        // Set "discard after suspend" checkbox
        const discardAfterSuspendCheckbox = document.getElementById('discardAfterSuspend');
        if (discardAfterSuspendCheckbox) {
            discardAfterSuspendCheckbox.checked = items.discardAfterSuspend === true; // Default to false
        }
        
        console.log('Options initialized with theme:', theme);
    });
}

function setupEventListeners() {
    console.log('Setting up options event listeners...');
    
    // Theme selector
    setupThemeSelector();
    
    // Auto-suspend time
    setupAutoSuspendTime();
    
    // Pinned tabs checkbox
    setupPinnedCheckbox();
    
    // Whitelist
    setupWhitelist();
    
    // Other checkboxes
    setupOtherCheckboxes();
}

function setupThemeSelector() {
    const themeSelect = document.getElementById('theme');
    if (themeSelect) {
        themeSelect.addEventListener('change', function() {
            const theme = this.value;
            console.log('Theme changed to:', theme);
            
            chrome.storage.sync.set({ theme: theme }, function() {
                console.log('Theme saved:', theme);
                applyTheme(theme);
            });
        });
    }
}

function setupAutoSuspendTime() {
    const autoSuspendTime = document.getElementById('timeToSuspend');
    if (autoSuspendTime) {
        autoSuspendTime.addEventListener('change', function() {
            const time = parseInt(this.value) || 60;
            console.log('Auto-suspend time changed to:', time);
            
            chrome.storage.sync.set({ autoSuspendTime: time }, function() {
                console.log('Auto-suspend time saved:', time);
            });
        });
    }
}

function setupPinnedCheckbox() {
    const pinnedCheckbox = document.getElementById('dontSuspendPinned');
    if (pinnedCheckbox) {
        pinnedCheckbox.addEventListener('change', function() {
            const checked = this.checked;
            console.log('Don\'t suspend pinned tabs changed to:', checked);
            
            chrome.storage.sync.set({ pinned: checked }, function() {
                console.log('Don\'t suspend pinned tabs saved:', checked);
            });
        });
    }
}

function setupWhitelist() {
    const whiteListTextarea = document.getElementById('whitelist');
    if (whiteListTextarea) {
        whiteListTextarea.addEventListener('blur', function() {
            const whitelist = this.value;
            console.log('Whitelist updated');
            
            chrome.storage.sync.set({ whiteList: whitelist }, function() {
                console.log('Whitelist saved');
            });
        });
    }
}

function setupOtherCheckboxes() {
    // Never suspend forms
    const neverSuspendFormsCheckbox = document.getElementById('neverSuspendForms');
    if (neverSuspendFormsCheckbox) {
        neverSuspendFormsCheckbox.addEventListener('change', function() {
            const checked = this.checked;
            console.log('Never suspend forms changed to:', checked);
            
            chrome.storage.sync.set({ neverSuspendForms: checked }, function() {
                console.log('Never suspend forms saved:', checked);
            });
        });
    }
    
    // Suspend in place of discard
    const suspendInPlaceCheckbox = document.getElementById('suspendInPlaceOfDiscard');
    if (suspendInPlaceCheckbox) {
        suspendInPlaceCheckbox.addEventListener('change', function() {
            const checked = this.checked;
            console.log('Suspend in place of discard changed to:', checked);
            
            chrome.storage.sync.set({ suspendInPlaceOfDiscard: checked }, function() {
                console.log('Suspend in place of discard saved:', checked);
            });
        });
    }
    
    // Discard after suspend
    const discardAfterSuspendCheckbox = document.getElementById('discardAfterSuspend');
    if (discardAfterSuspendCheckbox) {
        discardAfterSuspendCheckbox.addEventListener('change', function() {
            const checked = this.checked;
            console.log('Discard after suspend changed to:', checked);
            
            chrome.storage.sync.set({ discardAfterSuspend: checked }, function() {
                console.log('Discard after suspend saved:', checked);
            });
        });
    }
}

function applyTheme(theme) {
    const body = document.body;
    
    // Remove existing theme classes
    body.classList.remove('light-theme', 'dark-theme', 'system-theme');
    
    if (theme === 'light') {
        body.classList.add('light-theme');
        console.log('Applied light theme');
    } else if (theme === 'dark') {
        body.classList.add('dark-theme');
        console.log('Applied dark theme');
    } else {
        // System theme - follow OS preference
        body.classList.add('system-theme');
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            body.classList.add('dark-theme');
            console.log('Applied system theme (dark)');
        } else {
            body.classList.add('light-theme');
            console.log('Applied system theme (light)');
        }
    }
}

// Listen for system theme changes
if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        chrome.storage.sync.get(['theme'], function(items) {
            if (items.theme === 'system' || !items.theme) {
                applyTheme('system');
            }
        });
    });
}

console.log('Options.js loaded');
