/**
 * COMPLETE SESSION MANAGEMENT WITH TAB PROTECTION
 */

console.log('🚀 Complete Session Management Service Worker starting...');

// Global state
let isServiceWorkerReady = false;
let suspendedTabs = new Map();
let currentSessionId = null;
let contextMenusCreated = false;
let originalTabs = new Map(); // Store original tabs for protection

// Initialize service worker with complete functionality
async function initializeServiceWorker() {
    try {
        console.log('🔧 Initializing Complete Session Management...');
        
        const defaults = {
            extensionEnabled: true,
            selectedTheme: 'purple',
            tabProtection: true,
            autoRestore: true,
            systemThemeBehavior: 'manual',
            suspendAfter: 60
        };
        
        // Initialize defaults
        for (const [key, value] of Object.entries(defaults)) {
            try {
                const result = await chrome.storage.local.get([key]);
                if (result[key] === undefined) {
                    await chrome.storage.local.set({ [key]: value });
                }
            } catch (error) {
                console.warn(`Failed to set default ${key}:`, error);
            }
        }
        
        // Get or create session ID
        const sessionResult = await chrome.storage.local.get(['currentSessionId']);
        if (!sessionResult.currentSessionId) {
            currentSessionId = `gs-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
            await chrome.storage.local.set({ currentSessionId: currentSessionId });
            console.log('✅ Created new session ID:', currentSessionId);
        } else {
            currentSessionId = sessionResult.currentSessionId;
            console.log('✅ Using existing session ID:', currentSessionId);
        }
        
        // Store all current tabs for protection
        await storeCurrentTabsForProtection();
        
        // Auto-restore suspended tabs if enabled
        const settings = await chrome.storage.local.get(['autoRestore', 'tabProtection']);
        if (settings.autoRestore) {
            await autoRestoreSuspendedTabs();
        }
        
        // Apply session ID to all tabs
        await applySessionIdToAllTabs();
        
        // Setup context menu
        if (!contextMenusCreated) {
            await setupContextMenu();
        }
        
        isServiceWorkerReady = true;
        console.log('✅ Complete Session Management initialized successfully');
        
    } catch (error) {
        console.error('❌ Service Worker initialization error:', error);
        isServiceWorkerReady = true;
    }
}

// Store current tabs for protection against extension reload
async function storeCurrentTabsForProtection() {
    try {
        const tabs = await chrome.tabs.query({});
        const protectedTabs = [];
        
        for (const tab of tabs) {
            if (canManageTab(tab)) {
                protectedTabs.push({
                    id: tab.id,
                    url: tab.url,
                    title: tab.title,
                    sessionId: currentSessionId,
                    timestamp: Date.now(),
                    protected: true
                });
                
                // Store in memory map
                originalTabs.set(tab.id, {
                    url: tab.url,
                    title: tab.title,
                    sessionId: currentSessionId
                });
            }
        }
        
        if (protectedTabs.length > 0) {
            await chrome.storage.local.set({ 
                protectedTabs: protectedTabs,
                [`session_${currentSessionId}_protected`]: protectedTabs
            });
            console.log(`✅ Protected ${protectedTabs.length} tabs from extension reload`);
        }
    } catch (error) {
        console.error('❌ Error storing protected tabs:', error);
    }
}

// Auto-restore suspended tabs after browser restart
async function autoRestoreSuspendedTabs() {
    try {
        const result = await chrome.storage.local.get(['protectedTabs', `session_${currentSessionId}_protected`]);
        const tabsToRestore = result.protectedTabs || result[`session_${currentSessionId}_protected`] || [];
        
        if (tabsToRestore.length > 0) {
            console.log(`🔄 Auto-restoring ${tabsToRestore.length} protected tabs...`);
            
            // Only restore if current tabs are minimal (like new tab page)
            const currentTabs = await chrome.tabs.query({});
            const nonSystemTabs = currentTabs.filter(canManageTab);
            
            if (nonSystemTabs.length <= 1) {
                for (const tab of tabsToRestore) {
                    if (tab.url && canManageTab(tab)) {
                        await chrome.tabs.create({ 
                            url: tab.url, 
                            title: tab.title,
                            active: false 
                        });
                    }
                }
                console.log('✅ Auto-restore completed');
            }
        }
    } catch (error) {
        console.error('❌ Auto-restore error:', error);
    }
}

// Apply session ID to all current tabs
async function applySessionIdToAllTabs() {
    try {
        const tabs = await chrome.tabs.query({});
        const sessionTabs = [];
        
        for (const tab of tabs) {
            if (canManageTab(tab)) {
                sessionTabs.push({
                    id: tab.id,
                    url: tab.url,
                    title: tab.title,
                    sessionId: currentSessionId,
                    timestamp: Date.now()
                });
            }
        }
        
        if (sessionTabs.length > 0) {
            await chrome.storage.local.set({ 
                [`session_${currentSessionId}`]: sessionTabs,
                currentSessionTabs: sessionTabs
            });
            console.log(`✅ Applied session ID ${currentSessionId} to ${sessionTabs.length} tabs`);
        }
    } catch (error) {
        console.error('❌ Error applying session ID:', error);
    }
}

// UNIFIED MESSAGE HANDLER
function handleMessage(request, sender, sendResponse) {
    console.log('📨 Background received:', request.action);
    
    switch(request.action) {
        case 'exportTabs':
            chrome.tabs.query({}, (tabs) => {
                const exportTabs = tabs.filter(canManageTab).map((tab) => ({
                    title: tab.title,
                    url: tab.url,
                    sessionId: currentSessionId,
                    timestamp: Date.now()
                }));
                console.log('✅ Exporting', exportTabs.length, 'tabs with session ID:', currentSessionId);
                sendResponse({tabs: exportTabs, sessionId: currentSessionId});
            });
            return true;
            
        case 'backupTabs':
            chrome.tabs.query({}, (tabs) => {
                const backupTabs = tabs.filter(canManageTab).map((tab) => ({
                    id: tab.id,
                    title: tab.title,
                    url: tab.url,
                    sessionId: currentSessionId,
                    timestamp: Date.now()
                }));
                
                // Use provided backup name or generate default
                let backupName = request.backupName;
                if (!backupName || backupName.trim() === '') {
                    const now = new Date();
                    backupName = `backup_${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}-${String(now.getMinutes()).padStart(2,'0')}`;
                }
                
                const backupData = {
                    name: backupName,
                    sessionId: currentSessionId,
                    tabs: backupTabs,
                    created: Date.now(),
                    count: backupTabs.length
                };
                
                chrome.storage.local.set({ 
                    [`session_${currentSessionId}`]: backupTabs,
                    [`backup_${backupName}`]: backupData,
                    currentSessionTabs: backupTabs,
                    protectedTabs: backupTabs
                }, () => {
                    console.log(`✅ Backed up ${backupTabs.length} tabs as "${backupName}" with session ID: ${currentSessionId}`);
                    sendResponse({
                        success: true, 
                        count: backupTabs.length, 
                        sessionId: currentSessionId,
                        backupName: backupName
                    });
                });
            });
            return true;
            
        case 'createNewSession':
            chrome.tabs.query({}, async (tabs) => {
                try {
                    // First backup current session
                    const currentTabs = tabs.filter(canManageTab).map((tab) => ({
                        id: tab.id,
                        title: tab.title,
                        url: tab.url,
                        sessionId: currentSessionId,
                        timestamp: Date.now()
                    }));
                    
                    // Save current session
                    if (currentTabs.length > 0) {
                        await chrome.storage.local.set({ 
                            [`session_${currentSessionId}`]: currentTabs,
                            [`backup_previous_${Date.now()}`]: {
                                name: `Previous Session ${new Date().toLocaleString()}`,
                                sessionId: currentSessionId,
                                tabs: currentTabs,
                                created: Date.now()
                            }
                        });
                    }
                    
                    // Create new session ID
                    const newSessionId = `gs-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
                    
                    // Suspend ALL manageable tabs with new session ID
                    let suspendedCount = 0;
                    const suspendPromises = tabs.map(async (tab) => {
                        if (canManageTab(tab)) {
                            try {
                                const suspendedUrl = chrome.runtime.getURL('suspended.html') + 
                                    '?uri=' + encodeURIComponent(tab.url) + 
                                    '&title=' + encodeURIComponent(tab.title) +
                                    '&sessionId=' + encodeURIComponent(newSessionId) +
                                    '&tabId=' + encodeURIComponent(tab.id);
                                
                                await chrome.tabs.update(tab.id, { url: suspendedUrl });
                                suspendedCount++;
                                
                                // Store suspended tab info
                                suspendedTabs.set(tab.id, {
                                    id: tab.id,
                                    url: tab.url,
                                    title: tab.title,
                                    sessionId: newSessionId,
                                    suspended: Date.now()
                                });
                                
                            } catch (error) {
                                console.error('Error suspending tab:', error);
                            }
                        }
                    });
                    
                    await Promise.all(suspendPromises);
                    
                    // Update current session ID
                    await chrome.storage.local.set({ currentSessionId: newSessionId });
                    currentSessionId = newSessionId;
                    
                    // Apply new session to all tabs
                    await applySessionIdToAllTabs();
                    await storeCurrentTabsForProtection();
                    
                    console.log(`✅ Created new session ${newSessionId}, suspended ${suspendedCount} tabs`);
                    
                    sendResponse({
                        success: true,
                        sessionId: newSessionId,
                        suspended: suspendedCount,
                        previousCount: currentTabs.length
                    });
                    
                } catch (error) {
                    console.error('❌ Error creating new session:', error);
                    sendResponse({
                        success: false,
                        error: error.message
                    });
                }
            });
            return true;
            
        case 'restoreSession':
            const sessionId = request.sessionId;
            console.log('🔄 Restoring session:', sessionId);
            
            chrome.storage.local.get([`session_${sessionId}`, sessionId], (result) => {
                let sessionTabs = result[`session_${sessionId}`] || result[sessionId] || [];
                
                if (sessionTabs.length === 0) {
                    // Try to find backup with this session ID
                    chrome.storage.local.get(null, (allData) => {
                        const backupKey = Object.keys(allData).find(key => 
                            key.startsWith('backup_') && allData[key].sessionId === sessionId
                        );
                        
                        if (backupKey) {
                            sessionTabs = allData[backupKey].tabs || [];
                        }
                        
                        if (sessionTabs.length > 0) {
                            sessionTabs.forEach((tab) => {
                                if (tab.url && canManageTab(tab)) {
                                    chrome.tabs.create({url: tab.url, title: tab.title});
                                }
                            });
                            sendResponse({success: true, restored: sessionTabs.length, sessionId: sessionId});
                        } else {
                            sendResponse({success: false, error: 'Session not found', sessionId: sessionId});
                        }
                    });
                } else {
                    sessionTabs.forEach((tab) => {
                        if (tab.url && canManageTab(tab)) {
                            chrome.tabs.create({url: tab.url, title: tab.title});
                        }
                    });
                    sendResponse({success: true, restored: sessionTabs.length, sessionId: sessionId});
                }
            });
            return true;
            
        case 'getSessionId':
            sendResponse({sessionId: currentSessionId});
            return true;
            
        case 'getCurrentSessionId':
            sendResponse({success: true, sessionId: currentSessionId});
            return true;
            
        case 'importTabs':
            try {
                const imported = JSON.parse(request.jsonData);
                const tabsArray = imported.tabs || imported;
                if (!Array.isArray(tabsArray)) {
                    sendResponse({success: false, error: "Invalid format"});
                    return true;
                }
                tabsArray.forEach((tab) => {
                    if (tab.url && canManageTab(tab)) {
                        chrome.tabs.create({url: tab.url});
                    }
                });
                sendResponse({success: true, imported: tabsArray.length});
            } catch (err) {
                console.error('Import error:', err);
                sendResponse({success: false, error: err.message});
            }
            return true;
            
        case 'getBackupsList':
            chrome.storage.local.get(null, (data) => {
                const backups = Object.keys(data)
                    .filter(key => key.startsWith('backup_'))
                    .map(key => data[key])
                    .filter(backup => backup && backup.name)
                    .sort((a, b) => b.created - a.created);
                sendResponse({backups: backups});
            });
            return true;
            
        // Original tab management functions
        case 'suspendTab':
            suspendTab(request.tabId || sender.tab?.id).then((result) => {
                sendResponse(result);
            });
            return true;
            
        case 'unsuspendTab':
            unsuspendTab(request.tabId || sender.tab?.id).then((result) => {
                sendResponse(result);
            });
            return true;
            
        case 'suspendOtherTabs':
            suspendOtherTabs(request.activeTabId || sender.tab?.id).then((result) => {
                sendResponse(result);
            });
            return true;
            
        case 'unsuspendAllTabs':
            unsuspendAllTabs().then((result) => {
                sendResponse(result);
            });
            return true;
            
        case 'getSuspendedCount':
            getSuspendedTabsCount().then((result) => {
                sendResponse(result);
            });
            return true;
            
        case 'openOptions':
            chrome.runtime.openOptionsPage();
            sendResponse({success: true});
            return true;
            
        case 'getTabInfo':
            getTabInfo(request.tabId).then((result) => {
                sendResponse(result);
            });
            return true;
            
        default:
            sendResponse({success: false, error: 'Unknown action: ' + request.action});
            return true;
    }
}

// Utility functions
function canManageTab(tab) {
    return tab && 
           tab.url &&
           !tab.url.startsWith('chrome://') && 
           !tab.url.startsWith('chrome-extension://') && 
           !tab.url.includes('suspended.html') &&
           !tab.url.startsWith('about:') &&
           !tab.url.startsWith('moz-extension://') &&
           tab.url !== '' && 
           tab.url !== 'about:blank';
}

// Tab suspension functions
async function suspendTab(tabId) {
    try {
        if (!tabId) return { success: false, error: 'No tab ID provided' };
        
        const tab = await chrome.tabs.get(tabId);
        if (!canManageTab(tab)) {
            return { success: false, error: 'Tab cannot be suspended' };
        }
        
        const suspendedUrl = chrome.runtime.getURL('suspended.html') + 
            '?uri=' + encodeURIComponent(tab.url) + 
            '&title=' + encodeURIComponent(tab.title) +
            '&sessionId=' + encodeURIComponent(currentSessionId) +
            '&tabId=' + encodeURIComponent(tab.id);
        
        await chrome.tabs.update(tabId, { url: suspendedUrl });
        
        suspendedTabs.set(tabId, {
            id: tabId,
            url: tab.url,
            title: tab.title,
            sessionId: currentSessionId,
            suspended: Date.now()
        });
        
        return { success: true };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function unsuspendTab(tabId) {
    try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.url.includes('suspended.html')) {
            const urlParams = new URLSearchParams(tab.url.split('?')[1] || '');
            const originalUrl = urlParams.get('uri') || urlParams.get('url');
            
            if (originalUrl) {
                await chrome.tabs.update(tabId, { url: decodeURIComponent(originalUrl) });
                suspendedTabs.delete(tabId);
                return { success: true };
            }
        }
        return { success: false, error: 'Tab is not suspended' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function suspendOtherTabs(activeTabId) {
    try {
        const tabs = await chrome.tabs.query({ currentWindow: true });
        let suspended = 0;
        
        for (const tab of tabs) {
            if (tab.id !== activeTabId && canManageTab(tab)) {
                const result = await suspendTab(tab.id);
                if (result.success) suspended++;
            }
        }
        
        return { success: true, suspended };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function unsuspendAllTabs() {
    try {
        const tabs = await chrome.tabs.query({});
        let unsuspended = 0;
        
        for (const tab of tabs) {
            if (tab.url.includes('suspended.html')) {
                const result = await unsuspendTab(tab.id);
                if (result.success) unsuspended++;
            }
        }
        
        return { success: true, unsuspended };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function getSuspendedTabsCount() {
    try {
        const tabs = await chrome.tabs.query({});
        const suspendedCount = tabs.filter((tab) => tab.url.includes('suspended.html')).length;
        return {
            success: true,
            count: suspendedCount,
            estimatedMemory: suspendedCount * 75
        };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function getTabInfo(tabId) {
    try {
        let tab;
        if (tabId) {
            tab = await chrome.tabs.get(tabId);
        } else {
            [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        }
        
        return {
            success: true,
            tab: {
                id: tab.id,
                title: tab.title,
                url: tab.url,
                sessionId: currentSessionId,
                suspended: tab.url.includes('suspended.html')
            }
        };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// Context menu setup
async function setupContextMenu() {
    return new Promise((resolve) => {
        chrome.contextMenus.removeAll(() => {
            const menuItems = [
                { id: 'suspend-tab', title: '💤 Suspend this tab', contexts: ['page'] },
                { id: 'suspend-other', title: '😴 Suspend other tabs', contexts: ['page'] },
                { id: 'unsuspend-all', title: '🔄 Unsuspend all tabs', contexts: ['page'] }
            ];
            
            let itemsCreated = 0;
            const totalItems = menuItems.length;
            
            menuItems.forEach((item) => {
                chrome.contextMenus.create(item, () => {
                    if (chrome.runtime.lastError) {
                        console.warn(`Context menu creation error for ${item.id}:`, chrome.runtime.lastError.message);
                    }
                    
                    itemsCreated++;
                    if (itemsCreated === totalItems) {
                        contextMenusCreated = true;
                        resolve();
                    }
                });
            });
        });
    });
}

// TAB PROTECTION - Prevent tabs from closing on extension reload
chrome.tabs.onRemoved.addListener(async (tabId, removeInfo) => {
    try {
        const settings = await chrome.storage.local.get(['tabProtection']);
        if (settings.tabProtection) {
            // If we had this tab stored, keep it protected
            if (originalTabs.has(tabId)) {
                const tabInfo = originalTabs.get(tabId);
                const protectedTabs = await chrome.storage.local.get(['protectedTabs']);
                let tabs = protectedTabs.protectedTabs || [];
                
                // Add this tab to protected list if not already there
                if (!tabs.find(t => t.id === tabId)) {
                    tabs.push({
                        id: tabId,
                        url: tabInfo.url,
                        title: tabInfo.title,
                        sessionId: tabInfo.sessionId,
                        timestamp: Date.now(),
                        protected: true
                    });
                    
                    await chrome.storage.local.set({ protectedTabs: tabs });
                    console.log(`🛡️ Protected tab ${tabId} from removal`);
                }
            }
        }
    } catch (error) {
        console.error('Tab protection error:', error);
    }
});

// Update session when tabs change
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && canManageTab(tab)) {
        // Store this tab for protection
        originalTabs.set(tabId, {
            url: tab.url,
            title: tab.title,
            sessionId: currentSessionId
        });
        
        // Update session periodically
        await applySessionIdToAllTabs();
        await storeCurrentTabsForProtection();
    }
});

// Event listeners
chrome.runtime.onInstalled.addListener((details) => {
    console.log('🔧 Extension installed:', details.reason);
    initializeServiceWorker();
});

chrome.runtime.onStartup.addListener(() => {
    console.log('🚀 Extension startup');
    initializeServiceWorker();
});

chrome.runtime.onMessage.addListener(handleMessage);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    try {
        switch(info.menuItemId) {
            case 'suspend-tab':
                await suspendTab(tab.id);
                break;
            case 'suspend-other':
                await suspendOtherTabs(tab.id);
                break;
            case 'unsuspend-all':
                await unsuspendAllTabs();
                break;
        }
    } catch (error) {
        console.error('Context menu action error:', error);
    }
});

// Initialize immediately
initializeServiceWorker();
